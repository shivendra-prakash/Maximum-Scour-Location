function s = sigmoidfunc(z)

s = zeros(size(z));
s = 1./(1 + exp(-z));

end
