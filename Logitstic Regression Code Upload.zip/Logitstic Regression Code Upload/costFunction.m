function [K,grad] = costFunction(theta,X,y)

p = length(y);                           
K = 0;
grad = zeros(size(theta));

for i = 1:p
    K = K - (y(i)*log(sigmoidfunc(theta'*X(i,:)')) + (1-y(i))*log(1 - sigmoidfunc(theta'*X(i,:)')))/p;
    grad = grad + ((sigmoidfunc(theta'*X(i,:)') - y(i))*X(i,:)')/p;
end
end
