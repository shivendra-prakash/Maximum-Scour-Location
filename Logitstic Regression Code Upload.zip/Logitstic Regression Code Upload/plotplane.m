function[hndl] = plotplane(X,theta)
x1 = X(:,2);
x2 = X(:,3);
x3 = X(:,4);

xdom = min(x1):.01:max(x1);
ydom = min(x2):.01:max(x2);

[xgrid,ygrid] = meshgrid(xdom,ydom);

d = theta(1);
a = theta(2);
b = theta(3);
c = theta(4);

zgrid = (- d - a*xgrid - b*ygrid)/c;

hndl = surf(xgrid,ygrid,zgrid,'LineStyle','none');

end

