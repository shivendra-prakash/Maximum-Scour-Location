function legendHndls = plotData2(X,y,z)

figure; hold on;

pos1 = find(y == 1 & z == 32);
neg1 = find(y == 0 & z == 31);

pos2 = find(y == 1 & z == 42);
neg2 = find(y == 0 & z == 41);

p1 = plot3(X(pos1,1),X(pos1,2),X(pos1,3),'ko','MarkerFaceColor','k');
p2 = plot3(X(neg1,1),X(neg1,2),X(neg1,3),'rs','MarkerFaceColor','r');

p3 = plot3(X(pos2,1),X(pos2,2),X(pos2,3),'k*','MarkerFaceColor','k');
p4 = plot3(X(neg2,1),X(neg2,2),X(neg2,3),'r>','MarkerFaceColor','r');

legend([p1 p2 p3 p4],{'G3F','G3C','G2F','G2C'});
legendHndls = [p1 p2 p3 p4];

hold off;
end
