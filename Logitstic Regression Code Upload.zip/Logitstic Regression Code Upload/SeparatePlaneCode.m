%% Separation Plane using Logistic Regression

close all;
clear all;
clc;

%% Plot data in 3D

A = xlsread('Separation Plane Plot.xlsx',1);

X = A(:,[1,2,3]);
y = A(:,5);
z = A(:,6);
[m, n] = size(X);

X = [ones(m, 1) X];
legendHndls = plotData2(X(:,[2,3,4]),y,z);

hold on;
xlabel('H_b/Y_1')          
ylabel('Fr')          
zlabel('d_*')          
grid on

%% Separation plane

options = optimset('GradObj','on','MaxIter',1000,'MaxFunEvals',1000);

[theta, cost] = ...
	fminunc(@(t)(costFunction(t,X,y)),[0;0;0;0],options);
hold on
plotplane(X,theta);

%% Validation using HL2010 Data

V = xlsread('Separation Plane Plot.xlsx',2);
p5 = plot3(V(:,2),V(:,3),V(:,4),'kp','MarkerFaceColor','k');

legend([legendHndls,p5],{'G3F','G3C','G2F','G2C','HL2010'});
set(gca,'FontSize',12);
set(gca,'fontname','times');

%%

